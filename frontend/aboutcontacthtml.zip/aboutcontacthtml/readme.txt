# Budget Tracker - About & Contact Page

This is the About & Contact page for the Budget Tracker project. It's responsive and ready to link with the rest of the app.

## Files

- `about.html` - the page itself  
- `style.css` - styling for the page  

## Features

- Nav bar with links to Home, Budget Tracker, About, and a Login/Sign Up button  
- About section with project info and mission  
- Contact form with "Message Sent!" confirmation  
- GitHub and Twitter icons (SVG)  
- Works on desktop and mobile  

## How to Use

1. Put `about.html` and `style.css` in the same folder  
2. Make sure linked pages (`index.html`, `budget.html`, `login.html`) exist  
3. Open `about.html` in a browser  

No extra images or assets are needed.
